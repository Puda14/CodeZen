# Problem02

This is Problem Template. It is a placeholder for a contest that will be held in the future.
